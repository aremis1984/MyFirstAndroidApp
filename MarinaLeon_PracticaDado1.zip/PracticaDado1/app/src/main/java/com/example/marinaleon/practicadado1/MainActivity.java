package com.example.marinaleon.practicadado1;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



        public void comenzar(View view) {

            TextView turno = (TextView) findViewById(R.id.control);
            String jugador = (String) turno.getText();


            TextView acumulado = (TextView) findViewById(R.id.acumulado);
            acumulado.setText(R.string.cero);

            Button start = (Button) findViewById(R.id.buttonComenzarJ1);
            Button start2 = (Button) findViewById(R.id.buttonComenzarJ2);

            if (jugador == getString(R.string.uno)) {
                findViewById(R.id.textActualJ1).setVisibility(view.VISIBLE);
                findViewById(R.id.textActualJ2).setVisibility(view.INVISIBLE);

                start.setVisibility(View.INVISIBLE);
            } else {
                findViewById(R.id.textActualJ1).setVisibility(view.INVISIBLE);
                findViewById(R.id.textActualJ2).setVisibility(view.VISIBLE);

                start2.setVisibility(View.INVISIBLE);
            }

            Button lanzar = (Button) findViewById(R.id.buttonLanzar);

            lanzar.setVisibility(View.VISIBLE);

        }

        public void animar_dado(final Timer timer, final View view) {

            timer.scheduleAtFixedRate(new TimerTask() {
                final int[] cont = new int[1];
                final int[] aux = new int[1];
                public void run() {
                    runOnUiThread(new Runnable() {
                        ImageView dado = (ImageView) findViewById(R.id.imageDado);
                        // int aux;
                        Random r = new Random();
                        int k = r.nextInt(7 - 1) + 1;
                        public void run() {
                            cont[0]++;

                            if(cont[0] == 5) {
                                timer.cancel();
                                valor_dado(view, aux[0]);

                            }else {
                                switch (k) {
                                    case 1:
                                        dado.setImageResource(R.drawable.dado1);
                                        break;
                                    case 2:
                                        dado.setImageResource(R.drawable.dado2);
                                        break;
                                    case 3:
                                        dado.setImageResource(R.drawable.dado3);
                                        break;
                                    case 4:
                                        dado.setImageResource(R.drawable.dado4);
                                        break;
                                    case 5:
                                        dado.setImageResource(R.drawable.dado5);
                                        break;
                                    case 6:
                                        dado.setImageResource(R.drawable.dado6);
                                        break;
                                }
                                aux[0] = k;
                            }

                        }
                    });
                }

            }, 0, 200);

        }



        public void lanzar_dado(View view) {

            ImageView dado = (ImageView) findViewById(R.id.imageDado);
            dado.setVisibility(View.VISIBLE);
            Button lanzar = (Button) findViewById(R.id.buttonLanzar);
            lanzar.setEnabled(false);

            Button recoger = (Button) findViewById(R.id.buttonRecoger);
            recoger.setEnabled(false);

            Timer timer = new Timer();

            animar_dado(timer, view);
            //valor_dado(view);

            //  viewAux = view;

        }


        public void terminado(int i){
            if(i == 1){
                // valor_dado(viewAux);
            }
        }

    public void valor_dado(View view, int k){
        int total = 0;

        TextView turno = (TextView) findViewById(R.id.control);
        String jugador = (String) turno.getText();

        Button recoger = (Button) findViewById(R.id.buttonRecoger);
        recoger.setVisibility(View.VISIBLE);
        recoger.setEnabled(true);

        Button lanzar = (Button) findViewById(R.id.buttonLanzar);
        lanzar.setEnabled(true);

        ImageView dado = (ImageView) findViewById(R.id.imageDado);


        if (k == 1) {

            if (jugador == getString(R.string.uno)) {

                findViewById(R.id.textActualJ1).setVisibility(view.INVISIBLE);
                findViewById(R.id.textActualJ2).setVisibility(view.VISIBLE);
                TextView flag = (TextView) findViewById(R.id.control);
                flag.setText(R.string.dos);

            } else if (jugador == getString(R.string.dos)) {

                findViewById(R.id.textActualJ1).setVisibility(view.VISIBLE);
                findViewById(R.id.textActualJ2).setVisibility(view.INVISIBLE);
                TextView flag = (TextView) findViewById(R.id.control);
                flag.setText(R.string.uno);

            }
            reinicia(view);

        }

        if (k != 1) {
            TextView puntos = (TextView) findViewById(R.id.acumulado);
            String suma = puntos.getText().toString();
            int val = Integer.parseInt(suma);
            val = val + k;
            String resultado = String.valueOf(val);
            puntos.setText(resultado);

            if (jugador == getString(R.string.uno)) {
                TextView puntosTotal = (TextView) findViewById(R.id.textJugTotal1);
                String sumaTotal = puntosTotal.getText().toString();
                int valTotal = Integer.parseInt(sumaTotal);
                total = val + valTotal;

            } else {
                TextView puntosTotal = (TextView) findViewById(R.id.textJugTotal2);
                String sumaTotal = puntosTotal.getText().toString();
                int valTotal = Integer.parseInt(sumaTotal);
                total = val + valTotal;

            }

            if (total > 99) {
               recoger(view);

               //comprueba_fin(total, view, jugador);
            }
        }

    }


        public void reinicia(View view) {
            TextView reset = (TextView) findViewById(R.id.reset);
            String r = (String) reset.getText();

            if (r == getString(R.string.uno)) {
                reset.setText(R.string.cero);
            }


            Button start = (Button) findViewById(R.id.buttonComenzarJ1);
            Button start2 = (Button) findViewById(R.id.buttonComenzarJ2);

            Button lanzar = (Button) findViewById(R.id.buttonLanzar);
            Button recoger = (Button) findViewById(R.id.buttonRecoger);

            TextView turno = (TextView) findViewById(R.id.control);
            String jugador = (String) turno.getText();

            if (jugador == getString(R.string.uno)) {
                start.setVisibility(View.VISIBLE);
                start2.setVisibility(View.INVISIBLE);

            } else {
                start2.setVisibility(View.VISIBLE);
                start.setVisibility(View.INVISIBLE);

            }

            recoger.setVisibility(View.INVISIBLE);
            lanzar.setVisibility(View.INVISIBLE);
        }

        public void recoger(View view) {
            ProgressBar progressBar, progressBar2;
            TextView turno = (TextView) findViewById(R.id.control);
            String jugador = (String) turno.getText();
            int maxProgreso = 100;

            TextView puntos = (TextView) findViewById(R.id.acumulado);
            String suma = puntos.getText().toString();
            int val = Integer.parseInt(suma);

            if (jugador == getString(R.string.uno)) {
                //sumo puntos y cambio al dos

                TextView puntosTotal = (TextView) findViewById(R.id.textJugTotal1);
                String sumaTotal = puntosTotal.getText().toString();
                int valTotal = Integer.parseInt(sumaTotal);

                val = val + valTotal;

                String resultado = String.valueOf(val);
                puntosTotal.setText(resultado);

                progressBar = (ProgressBar) findViewById(R.id.progressBarJ1);
                progressBar.setProgress((int) (val * 100 / maxProgreso));


                TextView flag = (TextView) findViewById(R.id.control);
                flag.setText(R.string.dos);

            } else if (jugador == getString(R.string.dos)) {
                //sumo puntos y cambio al uno

                TextView puntosTotal = (TextView) findViewById(R.id.textJugTotal2);
                String sumaTotal = puntosTotal.getText().toString();
                int valTotal = Integer.parseInt(sumaTotal);
                val = val + valTotal;

                String resultado = String.valueOf(val);
                puntosTotal.setText(resultado);

                progressBar2 = (ProgressBar) findViewById(R.id.progressBarJ2);
                progressBar2.setProgress((int) (val * 100 / maxProgreso));


                TextView flag = (TextView) findViewById(R.id.control);
                flag.setText(R.string.uno);

            }
            ImageView dado = (ImageView) findViewById(R.id.imageDado);
            dado.setVisibility(View.INVISIBLE);

            comprueba_fin(val, view, jugador);
        }

        public void comprueba_fin(int val, final View view, final String jugador) {

            ProgressBar progressBar, progressBar2;
            int maxProgreso = 100;

            if (val >= 100) {


                final AlertDialog.Builder builder = new AlertDialog.Builder(this);

                if (jugador == getString(R.string.uno)) {
                    builder.setMessage(R.string.gana_uno)
                            .setTitle(R.string.fin)
                            .setCancelable(false);

                    //si gana el uno el proximo turno sera del dos y viceversa
                    TextView flag = (TextView) findViewById(R.id.control);
                    flag.setText(R.string.dos);


                } else {
                    builder.setMessage(R.string.gana_dos)
                            .setTitle(R.string.fin)
                            .setCancelable(false);

                    TextView flag = (TextView) findViewById(R.id.control);
                    flag.setText(R.string.uno);

                }

                builder.setPositiveButton(R.string.volver, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        TextView acumulado = (TextView) findViewById(R.id.acumulado);
                        acumulado.setText(R.string.cero);

                        ProgressBar progressBar, progressBar2;
                        progressBar = (ProgressBar) findViewById(R.id.progressBarJ1);
                        progressBar.setProgress((int) (0));
                        progressBar2 = (ProgressBar) findViewById(R.id.progressBarJ2);
                        progressBar2.setProgress((int) (0));


                        TextView reset = (TextView) findViewById(R.id.reset);
                        reset.setText(R.string.uno);

                        TextView puntosTotal1 = (TextView) findViewById(R.id.textJugTotal1);
                        puntosTotal1.setText(R.string.cero);
                        TextView puntosTotal2 = (TextView) findViewById(R.id.textJugTotal2);
                        puntosTotal2.setText(R.string.cero);

                        reinicia(view);
                    }
                });
                builder.setNegativeButton(R.string.salir, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            } else {
                reinicia(view);
            }

        }

    }


